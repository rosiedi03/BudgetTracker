# Budgetly frontend

React + TypeScript + Vite frontend for the supplied FastAPI Budget Tracker backend.

## Requirements
- Node.js 18+ and npm
- The FastAPI backend running at `http://127.0.0.1:8000`

## Run locally
1. Start the backend using the instructions in its README (`uv sync`, then `uv run fastapi dev`).
2. In this directory, install and start the frontend:

```bash
npm install
npm run dev
```

3. Open the Vite URL printed in the terminal (normally `http://localhost:5173`).

Vite proxies `/expenses`, `/income`, and `/health` to the backend at port 8000, so local development does not require CORS changes.

## Production API URL
For a separately hosted frontend, create `.env` with:

```env
VITE_API_URL=http://127.0.0.1:8000
```

Set this to the deployed backend URL before building. The backend must allow the frontend's origin through CORS when hosted on a different origin.

## Available API integration
The frontend uses the backend's existing routes:
- `GET/POST /expenses`
- `PUT/DELETE /expenses/{index}`
- `GET/POST /income`
- `GET /health`

The backend currently has no monthly-budget endpoint. Monthly budget values are therefore stored in browser `localStorage`, separately for each month and browser/device. Transaction data remains managed by the backend.

## Checks
```bash
npm run build
npm test
```

The project includes strict TypeScript checking as part of its production build. The frontend's browser storage budget is intentionally not represented as backend-persisted data.
