import { describe, expect, it, vi, afterEach } from "vitest";
import { api } from "./api";

afterEach(() => vi.unstubAllGlobals());

describe("backend API client", () => {
  it("loads expense rows from the existing endpoint", async () => {
    const rows = [{ amount: 12, category: "Food", date: "2026-11-13" }];
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true, json: async () => rows
    }));
    await expect(api.getExpenses()).resolves.toEqual(rows);
    expect(fetch).toHaveBeenCalledWith("/expenses", expect.objectContaining({ headers: expect.any(Object) }));
  });

  it("sends an expense using the backend's expected fields", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true, json: async () => ({ message: "Expense added successfully" })
    }));
    const payload = { amount: 15, category: "Food", date: "2026-11-13", description: "Lunch" };
    await api.addExpense(payload);
    expect(fetch).toHaveBeenCalledWith("/expenses", expect.objectContaining({
      method: "POST", body: JSON.stringify(payload)
    }));
  });

  it("surfaces backend validation errors", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: false, status: 422, json: async () => ({ detail: "Invalid amount" })
    }));
    await expect(api.getIncome()).rejects.toThrow("Invalid amount");
  });
});