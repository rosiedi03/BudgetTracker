export type Expense = {
  amount: number;
  category: string;
  date: string;
  description?: string;
  payer?: string;
};

export type Income = {
  amount: number;
  source: string;
  date: string;
  description?: string;
};

export type Transaction = {
  id: string;
  kind: "income" | "expense";
  amount: number;
  title: string;
  category: string;
  date: string;
  description?: string;
  apiIndex?: number;
};

export const CATEGORIES = [
  "Food", "Transportation", "Bills", "Entertainment", "Shopping", "Other"
];