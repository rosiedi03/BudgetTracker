import type { Expense, Income } from "./types";

const API_BASE = (import.meta.env.VITE_API_URL ?? "").replace(/\/$/, "");

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: { "Content-Type": "application/json", ...options?.headers }
    });
  } catch {
    throw new Error("Could not connect to the Budget Tracker API. Make sure the backend is running.");
  }
  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      message = typeof body.detail === "string" ? body.detail : message;
    } catch { /* response did not contain JSON */ }
    throw new Error(message);
  }
  return response.json() as Promise<T>;
}

export const api = {
  health: () => request<{ status: string }>("/health"),
  getExpenses: () => request<Expense[]>("/expenses"),
  addExpense: (data: Expense) => request<{ message: string }>("/expenses", {
    method: "POST", body: JSON.stringify(data)
  }),
  updateExpense: (index: number, data: Expense) => request<{ message: string }>(`/expenses/${index}`, {
    method: "PUT", body: JSON.stringify(data)
  }),
  deleteExpense: (index: number) => request<{ message: string }>(`/expenses/${index}`, {
    method: "DELETE"
  }),
  getIncome: () => request<Income[]>("/income"),
  addIncome: (data: Income) => request<{ message: string }>("/income", {
    method: "POST", body: JSON.stringify(data)
  })
};