import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import {
  ArrowDownLeft, ArrowUpRight, Wallet, Plus, LayoutDashboard, ReceiptText,
  ChartNoAxesCombined, Settings2, Search, Bell, ChevronDown, CalendarDays,
  Utensils, CarFront, House, Clapperboard, ShoppingBag, Ellipsis, Pencil,
  Trash2, X, Check, TrendingUp, CircleDollarSign, Menu, RefreshCw, AlertCircle
} from "lucide-react";
import { api } from "./api";
import { CATEGORIES, type Expense, type Income, type Transaction } from "./types";

type ModalKind = "expense" | "income" | "budget" | null;
const money = (value: number) => new Intl.NumberFormat("en-US", {
  style: "currency", currency: "USD"
}).format(value);
const today = () => new Date().toISOString().slice(0, 10);
const monthKey = (date = new Date()) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
const monthLabel = (date = new Date()) => date.toLocaleDateString("en-US", { month: "long", year: "numeric" });

function categoryIcon(category: string) {
  const props = { size: 17, strokeWidth: 2 };
  switch (category) {
    case "Food": return <Utensils {...props} />;
    case "Transportation": return <CarFront {...props} />;
    case "Bills": return <House {...props} />;
    case "Entertainment": return <Clapperboard {...props} />;
    case "Shopping": return <ShoppingBag {...props} />;
    default: return <Ellipsis {...props} />;
  }
}

export default function App() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [income, setIncome] = useState<Income[]>([]);
  const [budget, setBudget] = useState<number>(() => Number(localStorage.getItem(`budget-${monthKey()}`)) || 2000);
  const [modal, setModal] = useState<ModalKind>(null);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [activePage, setActivePage] = useState("Overview");
  const [query, setQuery] = useState("");
  const [period, setPeriod] = useState(monthKey());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [mobileNav, setMobileNav] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [expenseRows, incomeRows] = await Promise.all([api.getExpenses(), api.getIncome()]);
      setExpenses(expenseRows);
      setIncome(incomeRows);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong while loading your data.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => {
    const stored = Number(localStorage.getItem(`budget-${period}`));
    if (stored > 0) setBudget(stored);
    else if (period !== monthKey()) setBudget(0);
  }, [period]);

  const transactions = useMemo<Transaction[]>(() => [
    ...expenses.map((item, index) => ({
      id: `expense-${index}-${item.date}-${item.amount}`, kind: "expense" as const,
      amount: item.amount, title: item.description?.trim() || item.category,
      category: item.category, date: item.date, description: item.description, apiIndex: index
    })),
    ...income.map((item, index) => ({
      id: `income-${index}-${item.date}-${item.amount}`, kind: "income" as const,
      amount: item.amount, title: item.source, category: "Income",
      date: item.date, description: item.description
    }))
  ].sort((a, b) => b.date.localeCompare(a.date)), [expenses, income]);

  const monthTransactions = transactions.filter(item => item.date.startsWith(period));
  const monthExpenses = monthTransactions.filter(item => item.kind === "expense");
  const monthIncome = monthTransactions.filter(item => item.kind === "income");
  const totalExpenses = monthExpenses.reduce((sum, item) => sum + item.amount, 0);
  const totalIncome = monthIncome.reduce((sum, item) => sum + item.amount, 0);
  const remaining = totalIncome - totalExpenses;
  const budgetRemaining = budget - totalExpenses;
  const budgetPercent = budget > 0 ? Math.min(100, (totalExpenses / budget) * 100) : 0;
  const filtered = transactions.filter(item =>
    `${item.title} ${item.category} ${item.date}`.toLowerCase().includes(query.toLowerCase())
  );

  async function submitExpense(data: Expense) {
    try {
      if (editingIndex !== null) await api.updateExpense(editingIndex, data);
      else await api.addExpense(data);
      setNotice(editingIndex !== null ? "Expense updated." : "Expense added.");
      setModal(null); setEditingIndex(null); await refresh();
    } catch (err) { setError(err instanceof Error ? err.message : "Unable to save expense."); }
  }
  async function submitIncome(data: Income) {
    try {
      await api.addIncome(data);
      setNotice("Income added."); setModal(null); await refresh();
    } catch (err) { setError(err instanceof Error ? err.message : "Unable to save income."); }
  }
  async function removeExpense(index: number) {
    if (!window.confirm("Delete this expense?")) return;
    try { await api.deleteExpense(index); setNotice("Expense deleted."); await refresh(); }
    catch (err) { setError(err instanceof Error ? err.message : "Unable to delete expense."); }
  }
  function saveBudget(value: number) {
    localStorage.setItem(`budget-${period}`, String(value));
    setBudget(value); setModal(null); setNotice("Monthly budget saved on this device.");
  }
  function openEdit(index: number) { setEditingIndex(index); setModal("expense"); }
  function openAdd(kind: "expense" | "income") { setEditingIndex(null); setModal(kind); }

  const navItems = [
    { label: "Overview", icon: <LayoutDashboard size={19} /> },
    { label: "Transactions", icon: <ReceiptText size={19} /> },
    { label: "Reports", icon: <ChartNoAxesCombined size={19} /> }
  ];

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand"><div className="brand-mark"><Wallet size={21} /></div><span>budgetly</span></div>
        <div className="workspace-label">WORKSPACE</div>
        <nav className="nav-list">
          {navItems.map(item => <button key={item.label}
            className={`nav-item ${activePage === item.label ? "active" : ""}`}
            onClick={() => { setActivePage(item.label); setMobileNav(false); }}>
            {item.icon}<span>{item.label}</span>
          </button>)}
        </nav>
        <div className="sidebar-bottom">
          <div className="help-card">
            <div className="help-icon"><CircleDollarSign size={20} /></div>
            <strong>Small steps add up.</strong>
            <p>Keep an eye on your spending and make your money work for you.</p>
          </div>
          <button className="nav-item muted"><Settings2 size={19} /><span>Settings</span></button>
          <div className="profile">
            <div className="avatar">WD</div><div className="profile-copy"><strong>My account</strong><span>Personal workspace</span></div>
            <ChevronDown size={16} />
          </div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <button className="mobile-menu icon-button" onClick={() => setMobileNav(!mobileNav)} aria-label="Toggle menu"><Menu /></button>
          <div className="breadcrumb">Workspace <span>/</span> <strong>{activePage}</strong></div>
          <div className="top-actions">
            <div className="search-box"><Search size={17} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search transactions..." /></div>
            <button className="icon-button notification" aria-label="Notifications"><Bell size={19} /><i /></button>
            <div className="avatar top-avatar">WD</div>
          </div>
        </header>

        <div className="content">
          <div className="page-heading">
            <div><div className="eyebrow">YOUR MONEY, IN ONE PLACE</div><h1>{activePage === "Overview" ? "Good to see you!" : activePage}</h1>
              <p>{activePage === "Overview" ? "Here's what's happening with your finances." : "Keep track of where your money goes."}</p></div>
            <div className="heading-actions">
              <button className="button button-light" onClick={() => void refresh()}><RefreshCw size={16} /> Refresh</button>
              <button className="button button-primary" onClick={() => openAdd("expense")}><Plus size={17} /> Add transaction</button>
            </div>
          </div>

          {error && <div className="alert error-alert"><AlertCircle size={18} /><span>{error}</span><button onClick={() => setError("")}><X size={16} /></button></div>}
          {notice && <div className="alert success-alert"><Check size={17} /><span>{notice}</span><button onClick={() => setNotice("")}><X size={16} /></button></div>}

          <div className="period-row"><div className="period-title"><CalendarDays size={17} /> {period === monthKey() ? "This month" : "Selected month"}</div>
            <input aria-label="Select month" type="month" value={period} onChange={e => setPeriod(e.target.value)} />
          </div>

          {activePage === "Reports" ? (
            <Reports expenses={monthExpenses} income={totalIncome} totalExpenses={totalExpenses} budget={budget} />
          ) : activePage === "Transactions" ? (
            <section className="panel transaction-panel">
              <div className="panel-heading"><div><h2>All transactions</h2><p>Your latest income and expenses</p></div></div>
              <TransactionTable rows={filtered} onEdit={openEdit} onDelete={removeExpense} />
            </section>
          ) : (
            <>
              <section className="stats-grid">
                <StatCard title="Total income" amount={totalIncome} icon={<ArrowDownLeft size={19} />} tone="green" foot={`${monthIncome.length} income ${monthIncome.length === 1 ? "entry" : "entries"}`} />
                <StatCard title="Total expenses" amount={totalExpenses} icon={<ArrowUpRight size={19} />} tone="red" foot={`${monthExpenses.length} expense ${monthExpenses.length === 1 ? "entry" : "entries"}`} />
                <StatCard title="Money left" amount={remaining} icon={<Wallet size={19} />} tone="purple" foot="Income minus expenses" />
                <StatCard title="Monthly budget" amount={budget} icon={<ChartNoAxesCombined size={19} />} tone="blue" foot={budget > 0 ? `${money(budgetRemaining)} remaining` : "Set a spending limit"} />
              </section>

              <section className="middle-grid">
                <div className="panel budget-panel">
                  <div className="panel-heading"><div><h2>Monthly budget</h2><p>Track your spending against your limit</p></div>
                    <button className="text-button" onClick={() => setModal("budget")}>Edit budget</button></div>
                  <div className="budget-main"><div><span className="muted-label">You've spent</span><div className="big-amount">{money(totalExpenses)} <span>of {money(budget)}</span></div></div>
                    <div className={`budget-status ${budgetRemaining < 0 ? "over" : ""}`}>{budgetRemaining < 0 ? "Over budget" : "On track"}</div></div>
                  <div className="progress-track"><div className={`progress-fill ${budgetPercent >= 100 ? "danger-fill" : ""}`} style={{ width: `${budgetPercent}%` }} /></div>
                  <div className="progress-meta"><span>{budgetPercent.toFixed(0)}% used</span><strong>{money(budgetRemaining)} left</strong></div>
                  <div className="budget-note"><span className="note-dot" /> {budget > 0 && totalExpenses <= budget ? "You're doing well. Keep your spending on track!" : "Consider reviewing your spending for this month."}</div>
                </div>
                <div className="panel breakdown-panel">
                  <div className="panel-heading"><div><h2>Spending by category</h2><p>Where your money is going</p></div></div>
                  <CategoryBreakdown expenses={monthExpenses} total={totalExpenses} />
                </div>
              </section>

              <section className="panel transaction-panel">
                <div className="panel-heading"><div><h2>Recent transactions</h2><p>A quick look at your latest activity</p></div>
                  <button className="text-button" onClick={() => setActivePage("Transactions")}>View all <span>→</span></button></div>
                <TransactionTable rows={transactions.slice(0, 6)} onEdit={openEdit} onDelete={removeExpense} />
              </section>
            </>
          )}
          <footer>Made for better money habits <span>·</span> Budgetly</footer>
        </div>
      </main>

      {modal && <Modal kind={modal} editing={editingIndex !== null ? expenses[editingIndex] : undefined}
        onClose={() => { setModal(null); setEditingIndex(null); }}
        onExpense={submitExpense} onIncome={submitIncome} onBudget={saveBudget} currentBudget={budget} />}
      {loading && <div className="loading-indicator"><span className="spinner" /> Loading your finances...</div>}
    </div>
  );
}

function StatCard({ title, amount, icon, tone, foot }: {
  title: string; amount: number; icon: React.ReactNode; tone: string; foot: string; valueText?: string
}) {
  return <div className="stat-card"><div className="stat-top"><span>{title}</span><div className={`stat-icon ${tone}`}>{icon}</div></div>
    <div className="stat-amount">{valueText ?? money(amount)}</div><div className="stat-foot">{foot}</div></div>;
}

function CategoryBreakdown({ expenses, total }: { expenses: Transaction[]; total: number }) {
  const data = CATEGORIES.map(category => ({
    category, amount: expenses.filter(e => e.category === category).reduce((sum, e) => sum + e.amount, 0)
  })).filter(item => item.amount > 0).sort((a, b) => b.amount - a.amount);
  const colors = ["#7666e8", "#f0a44b", "#53b99a", "#e77b8c", "#6c9fe4", "#9aa4b2"];
  return <>{data.length ? <><div className="category-bars">{data.map((item, i) => <div key={item.category} className="category-bar" style={{ width: `${total ? item.amount / total * 100 : 0}%`, background: colors[i % colors.length] }} title={`${item.category}: ${money(item.amount)}`} />)}</div>
    <div className="category-list">{data.slice(0, 5).map((item, i) => <div className="category-line" key={item.category}><div className="category-name"><span className="legend-dot" style={{ background: colors[i % colors.length] }} />{item.category}</div><strong>{money(item.amount)}</strong><span className="category-percent">{Math.round(item.amount / total * 100)}%</span></div>)}</div></> :
    <div className="empty-state compact-empty"><div className="empty-icon"><ChartNoAxesCombined /></div><strong>No spending yet</strong><span>Add an expense to see your breakdown.</span></div>}</>;
}

function TransactionTable({ rows, onEdit, onDelete }: {
  rows: Transaction[]; onEdit: (index: number) => void; onDelete: (index: number) => void
}) {
  return <div className="table-wrap"><table><thead><tr><th>TRANSACTION</th><th>CATEGORY</th><th>DATE</th><th>AMOUNT</th><th></th></tr></thead>
    <tbody>{rows.map(row => <tr key={row.id}><td><div className="transaction-name"><div className={`transaction-icon ${row.kind}`}>{row.kind === "income" ? <ArrowDownLeft size={17} /> : categoryIcon(row.category)}</div>
      <div><strong>{row.title}</strong><span>{row.kind === "income" ? "Income" : "Expense"}</span></div></div></td>
      <td><span className="category-pill">{row.category}</span></td><td className="date-cell">{new Date(`${row.date}T12:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</td>
      <td className={`amount-cell ${row.kind}`}>{row.kind === "income" ? "+" : "−"}{money(row.amount)}</td>
      <td><div className="row-actions">{row.kind === "expense" && row.apiIndex !== undefined && <><button title="Edit expense" onClick={() => onEdit(row.apiIndex!)}><Pencil size={15} /></button><button title="Delete expense" onClick={() => onDelete(row.apiIndex!)}><Trash2 size={15} /></button></>}</div></td>
    </tr>)}</tbody></table>
    {!rows.length && <div className="empty-state"><div className="empty-icon"><ReceiptText /></div><strong>No transactions found</strong><span>Your transactions will appear here once you add them.</span></div>}
  </div>;
}

function Reports({ expenses, income, totalExpenses, budget }: { expenses: Transaction[]; income: number; totalExpenses: number; budget: number }) {
  const savings = income - totalExpenses;
  return <><div className="stats-grid report-stats"><StatCard title="Income" amount={income} icon={<ArrowDownLeft />} tone="green" foot="For selected month" /><StatCard title="Expenses" amount={totalExpenses} icon={<ArrowUpRight />} tone="red" foot="For selected month" /><StatCard title="Net savings" amount={savings} icon={<TrendingUp />} tone="purple" foot="Income minus expenses" /><StatCard title="Budget used" amount={0} valueText={`${budget ? Math.round(totalExpenses / budget * 100) : 0}%`} icon={<ChartNoAxesCombined />} tone="blue" foot="Percentage of budget" /></div>
    <div className="panel report-panel"><div className="panel-heading"><div><h2>Monthly spending report</h2><p>Category totals for the selected month</p></div></div><CategoryBreakdown expenses={expenses} total={totalExpenses} /></div></>;
}

function Modal({ kind, editing, onClose, onExpense, onIncome, onBudget, currentBudget }: {
  kind: Exclude<ModalKind, null>; editing?: Expense; onClose: () => void;
  onExpense: (data: Expense) => void; onIncome: (data: Income) => void;
  onBudget: (value: number) => void; currentBudget: number
}) {
  const [amount, setAmount] = useState(editing ? String(editing.amount) : "");
  const [category, setCategory] = useState(editing?.category ?? CATEGORIES[0]);
  const [title, setTitle] = useState(editing?.description ?? "");
  const [date, setDate] = useState(editing?.date ?? today());
  const [budget, setBudget] = useState(String(currentBudget || ""));
  const [saving, setSaving] = useState(false);
  const isExpense = kind === "expense";
  const isIncome = kind === "income";
  const heading = kind === "budget" ? "Set monthly budget" : editing ? "Edit expense" : isExpense ? "Add an expense" : "Add income";
  async function submit(event: FormEvent) {
    event.preventDefault();
    const value = Number(amount);
    if (kind === "budget") { if (Number(budget) > 0) onBudget(Number(budget)); return; }
    if (!(value > 0) || !Number.isFinite(value)) return;
    setSaving(true);
    if (isExpense) await onExpense({ amount: value, category, date, description: title });
    if (isIncome) await onIncome({ amount: value, source: title.trim(), date, description: "" });
    setSaving(false);
  }
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div className="modal-card" role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <div className="modal-heading"><div><div className="eyebrow">{kind === "budget" ? "PLAN AHEAD" : "TRANSACTION DETAILS"}</div><h2 id="modal-title">{heading}</h2></div><button className="icon-button" onClick={onClose} aria-label="Close"><X /></button></div>
      <form onSubmit={submit}>
        {kind === "budget" ? <><label>Monthly spending limit <span className="input-prefix">$</span><input autoFocus type="number" min="0.01" step="0.01" required value={budget} onChange={e => setBudget(e.target.value)} placeholder="2000.00" /></label><p className="form-hint">Your budget is saved in this browser for the selected month.</p></> :
          <><label>Amount <span className="input-prefix">$</span><input autoFocus type="number" min="0.01" step="0.01" required value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" /></label>
          <label>{isExpense ? "Category" : "Income source"}{isExpense ? <select value={category} onChange={e => setCategory(e.target.value)}>{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select> :
            <input required value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Part-time job" />}</label>
          {isExpense && <label>Description <input value={title} onChange={e => setTitle(e.target.value)} placeholder="What was this expense for?" /></label>}
          <label>Date <input type="date" required value={date} onChange={e => setDate(e.target.value)} /></label></>}
        <div className="modal-actions"><button type="button" className="button button-light" onClick={onClose}>Cancel</button><button className="button button-primary" disabled={saving}>{saving ? "Saving..." : kind === "budget" ? "Save budget" : editing ? "Save changes" : "Add transaction"}</button></div>
      </form>
    </div>
  </div>;
}